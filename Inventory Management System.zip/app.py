from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import os
import plotly.express as px
import plotly
import json
from datetime import datetime

app = Flask(__name__)

# Ensure data folder exists
if not os.path.exists('data'):
    os.makedirs('data')

data_file = 'data/data.csv'
history_file = 'data/history.csv'

# Initialize CSVs if they don't exist
if not os.path.exists(data_file):
    df = pd.DataFrame(columns=['date', 'time', 'item', 'price', 'quantity'])
    df.to_csv(data_file, index=False)

if not os.path.exists(history_file):
    history_df = pd.DataFrame(columns=['date', 'time', 'item', 'old_price', 'old_quantity', 'new_price', 'new_quantity', 'price_diff', 'quantity_diff'])
    history_df.to_csv(history_file, index=False)

@app.route('/', methods=['GET', 'POST'])
def index():
    data = pd.read_csv(data_file)
    history = pd.read_csv(history_file)

    if request.method == 'POST':
        if 'add_item' in request.form:
            item = request.form['item']
            price = float(request.form['price'])
            quantity = int(request.form['quantity'])
            now = datetime.now()
            date = now.strftime("%Y-%m-%d")
            time = now.strftime("%H:%M:%S")

            new_data = pd.DataFrame([[date, time, item, price, quantity]], columns=['date', 'time', 'item', 'price', 'quantity'])
            data = pd.concat([data, new_data], ignore_index=True)
            data.to_csv(data_file, index=False)

            return redirect(url_for('index'))

        elif 'update_item' in request.form:
            selected_item = request.form['selected_item']
            new_price = float(request.form['new_price'])
            new_quantity = int(request.form['new_quantity'])

            old_row = data[data['item'] == selected_item].iloc[-1]  # Latest entry
            old_price = old_row['price']
            old_quantity = old_row['quantity']
            price_diff = new_price - old_price
            quantity_diff = new_quantity - old_quantity

            now = datetime.now()
            date = now.strftime("%Y-%m-%d")
            time = now.strftime("%H:%M:%S")

            new_data = pd.DataFrame([[date, time, selected_item, new_price, new_quantity]], columns=['date', 'time', 'item', 'price', 'quantity'])
            data = pd.concat([data, new_data], ignore_index=True)
            data.to_csv(data_file, index=False)

            # Record the update in the history
            new_history = pd.DataFrame([[date, time, selected_item, old_price, old_quantity, new_price, new_quantity, price_diff, quantity_diff]], 
                                       columns=['date', 'time', 'item', 'old_price', 'old_quantity', 'new_price', 'new_quantity', 'price_diff', 'quantity_diff'])
            history = pd.concat([history, new_history], ignore_index=True)
            history.to_csv(history_file, index=False)

            return redirect(url_for('index'))

    # Create chart
    if not data.empty:
        fig = px.bar(data, x='item', y='quantity', title='Inventory Stock', color='item', text='quantity')
        fig.update_layout(plot_bgcolor='white')
        chart_html = plotly.io.to_html(fig, full_html=False)
    else:
        chart_html = "<h3 style='text-align:center;'>No data available</h3>"

    # Calculate grand total for current inventory
    total_value = (data['price'] * data['quantity']).sum()

    # New: Calculate old and new price grand totals from history
    old_total = history['old_price'].sum() if not history.empty else 0
    new_total = history['new_price'].sum() if not history.empty else 0

    # Calculate the difference
    price_difference = new_total - old_total

    return render_template('index.html', data=data, chart=chart_html, history=history, total_value=total_value,
                           old_total=old_total, new_total=new_total, price_difference=price_difference)

if __name__ == '__main__':
    app.run(debug=True)
